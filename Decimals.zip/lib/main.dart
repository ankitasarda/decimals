import 'package:flutter/material.dart';

void main() => runApp(DecimalLearningApp());

class DecimalLearningApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Decimals',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Decimals'),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: 50),
            SectionButton(
              text: 'Learn',
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LearnPage()),
                );
              },
            ),
            SizedBox(height: 50),
            SectionButton(
              text: 'Play',
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PlayPage()),
                );
              },
            ),
            SizedBox(height: 50),
            SectionButton(
              text: 'Practice',
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PracticePage()),
                );
              },
            ),
            Image.asset(
              'assets/kids.jpeg', // Path to the image you uploaded
              width: 300, // You can adjust the width
              height: 200, // You can adjust the height
              fit: BoxFit.cover,
            ),
          ],
        ),
      ),
    );
  }
}

class SectionButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;

  SectionButton({required this.text, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        padding: EdgeInsets.symmetric(
            horizontal: 50, vertical: 20), // Adjusted button size
        textStyle: TextStyle(fontSize: 18),
        minimumSize:
            Size(200, 60), // Minimum size of the button (width x height)
        shape: RoundedRectangleBorder(
          borderRadius:
              BorderRadius.circular(12), // Optional: rounded corners for button
        ),
      ),
      child: Text(text),
    );
  }
}

// Learn Page - Contains some basic information about decimals.
class LearnPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Learn Decimals'),
        backgroundColor: Colors.green,
        actions: [
          // Previous button - Goes back to the previous page
          IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context); // Goes back to the previous screen
            },
          ),
          // Next button - Navigates to the PlayPage
          IconButton(
            icon: Icon(Icons.arrow_forward),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        LearnPage2()), // Navigate to the PlayPage
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'What are Decimals?',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text(
              'Decimals are a way of expressing numbers that are not whole numbers. They are numbers with a dot, called a decimal point. The decimal point separates whole numbers from parts of a number.',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            Text(
              'Decimal Example:\n'
              '0.1 means one-tenth, 0.01 means one-hundredth, and so on.',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 30), // Adds space between text and image
            Image.asset(
              'assets/decimal1.png', // Path to the image you uploaded
              width: 200, // You can adjust the width
              height: 100, // You can adjust the height
              fit: BoxFit.cover,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // Back to Home
              },
              child: Text('Back to Home'),
            ),
          ],
        ),
      ),
    );
  }
}

class LearnPage2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Learn Decimals - Part 2'),
        backgroundColor: Colors.green,
        actions: [
          // Previous button - Goes back to the LearnPage
          IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context); // Goes back to the LearnPage
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Place Values in Decimals',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text(
              'Each number after the decimal point has a place value: tenths, hundredths, and thousandths.'
              'Example : In 0.25, 2 is in the tenths place, and 5 is in the hundredths place.',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            Image.asset(
              'assets/decimal2.png', // Add your own image path
              width: 200,
              height: 100,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(
                    context); // Go back to the previous page (LearnPage)
              },
              child: Text('Back to Learn Page'),
            ),
          ],
        ),
      ),
    );
  }
}

class LearnPage3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Learn Decimals - Part 3'),
        backgroundColor: Colors.green,
        actions: [
          // Previous button - Goes back to the LearnPage
          IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context); // Goes back to the LearnPage
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Reading Decimals',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text(
              'To read decimals:Say the whole number first'
              'Say “and” Say each number after the decimal. Don’t forget to say the units of the last digit!'
              'Example : In 0.25, 2 is in the tenths place, and 5 is in the hundredths place.',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            Image.asset(
              'assets/decimal2.png', // Add your own image path
              width: 200,
              height: 100,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(
                    context); // Go back to the previous page (LearnPage)
              },
              child: Text('Back to Learn Page'),
            ),
          ],
        ),
      ),
    );
  }
}

// Play Page - A simple interactive game could be here.
class PlayPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Play with Decimals'),
        backgroundColor: Colors.green,
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            // This could lead to a more detailed game or interactive activity
            showDialog(
              context: context,
              builder: (context) => AlertDialog(
                title: Text('Decimal Game'),
                content:
                    Text('This is where the play interaction will happen.'),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text('Close'),
                  ),
                ],
              ),
            );
          },
          child: Text('Start a Decimal Game'),
        ),
      ),
    );
  }
}

// Practice Page - Here kids can answer simple decimal-related questions.
class PracticePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Practice Decimals'),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Decimal Practice',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text(
              'Question 1: What is 0.7 + 0.3?',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            TextField(
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Enter Answer',
              ),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // You can add logic for validating the answer.
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text('Result'),
                    content: Text('Great job! Your answer is correct.'),
                    actions: [
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text('Close'),
                      ),
                    ],
                  ),
                );
              },
              child: Text('Submit Answer'),
            ),
          ],
        ),
      ),
    );
  }
}
